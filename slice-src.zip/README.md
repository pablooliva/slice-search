# Slice Search

This extension allows you to search a **Slice** of the internet. This is done by leveraging a [Google Programmable Search Engine](https://programmablesearchengine.google.com/) to restrict the URLs for specific searches.

### Attribution

This was inspired by Ravi's [extension](https://github.com/rsins/ravi-firefox-custom-search-engines).
